# ControlNet auxiliary models

This is a Pypi installable copied version of HED, MLSD and Human Pose auxiliary models: https://github.com/lllyasviel/ControlNet/tree/main/annotator

All credit goes to https://github.com/lllyasviel .
